﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CsharpNov20.Models;
using System.Security.Cryptography;

namespace CsharpNov20
{
    public partial class Form1 : Form
    {
        MyAcademyEntities db;
        public Form1()
        {
            db = new MyAcademyEntities();
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (rdbAdmin.Checked)
            {
                string name = txtAdminname.Text;
                string password = Hashit.Hasher(txtAdminpassword.Text);

                #region attempts
                //if(string.IsNullOrEmpty(name) || string.IsNullOrEmpty(password))
                //{
                //    MessageBox.Show("");
                //    return;
                //}

                //currentAdmin = db.Admins.FirstOrDefault(a => a.Name == name);

                //if(currentAdmin == null)
                //{
                //    MessageBox.Show("it is not found");
                //    return;
                //}

                //if (!Hashit.Checker(currentAdmin.Password, password))
                //{
                //    MessageBox.Show("passqword wrong");
                //    return;
                //}

                //new AdminPanel().ShowDialog();
#endregion
                if (db.Admins.FirstOrDefault(a => (a.Name == name) && (a.Password == password)) != null)
                {
                    AdminPanel adminPanel = new AdminPanel();
                    adminPanel.ShowDialog();
                    
                }
                else
                {
                    MessageBox.Show("Name or Password is wrong, please try again");
                }
            }

            
            txtAdminname.Text = "";
            txtAdminpassword.Text = "";
        }
    }
}
