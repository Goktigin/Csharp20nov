﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace CsharpNov20
{
    public partial class AdminPanel : Form
    {
       
        StudentViaAdm studentViaAdm;
        GroupViaAdm groupViaAdm;
        public AdminPanel()
        {
            InitializeComponent();
        }

        private void btnStudent_Click(object sender, EventArgs e)
        {
            studentViaAdm = new StudentViaAdm();
            studentViaAdm.ShowDialog();
        }

        private void btnGroup_Click(object sender, EventArgs e)
        {
            groupViaAdm = new GroupViaAdm();
            groupViaAdm.ShowDialog();
        }
    }
}
