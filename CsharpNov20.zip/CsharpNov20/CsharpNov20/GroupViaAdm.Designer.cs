﻿namespace CsharpNov20
{
    partial class GroupViaAdm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtgGroupList = new System.Windows.Forms.DataGridView();
            this.btngroupAdd = new System.Windows.Forms.Button();
            this.addGroupPanel = new System.Windows.Forms.Panel();
            this.lblgroupname = new System.Windows.Forms.Label();
            this.txtGroupName = new System.Windows.Forms.TextBox();
            this.btnaddgroup2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgGroupList)).BeginInit();
            this.addGroupPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtgGroupList
            // 
            this.dtgGroupList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgGroupList.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dtgGroupList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgGroupList.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgGroupList.GridColor = System.Drawing.SystemColors.ActiveBorder;
            this.dtgGroupList.Location = new System.Drawing.Point(0, 330);
            this.dtgGroupList.Name = "dtgGroupList";
            this.dtgGroupList.Size = new System.Drawing.Size(1061, 150);
            this.dtgGroupList.TabIndex = 0;
            // 
            // btngroupAdd
            // 
            this.btngroupAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngroupAdd.Location = new System.Drawing.Point(12, 12);
            this.btngroupAdd.Name = "btngroupAdd";
            this.btngroupAdd.Size = new System.Drawing.Size(155, 106);
            this.btngroupAdd.TabIndex = 1;
            this.btngroupAdd.Text = "Add Group";
            this.btngroupAdd.UseVisualStyleBackColor = true;
            this.btngroupAdd.Click += new System.EventHandler(this.btngroupAdd_Click);
            // 
            // addGroupPanel
            // 
            this.addGroupPanel.Controls.Add(this.btnaddgroup2);
            this.addGroupPanel.Controls.Add(this.lblgroupname);
            this.addGroupPanel.Controls.Add(this.txtGroupName);
            this.addGroupPanel.Location = new System.Drawing.Point(173, 12);
            this.addGroupPanel.Name = "addGroupPanel";
            this.addGroupPanel.Size = new System.Drawing.Size(876, 106);
            this.addGroupPanel.TabIndex = 2;
            this.addGroupPanel.Visible = false;
            // 
            // lblgroupname
            // 
            this.lblgroupname.AutoSize = true;
            this.lblgroupname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgroupname.Location = new System.Drawing.Point(31, 14);
            this.lblgroupname.Name = "lblgroupname";
            this.lblgroupname.Size = new System.Drawing.Size(61, 24);
            this.lblgroupname.TabIndex = 1;
            this.lblgroupname.Text = "Name";
            // 
            // txtGroupName
            // 
            this.txtGroupName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGroupName.Location = new System.Drawing.Point(35, 52);
            this.txtGroupName.Name = "txtGroupName";
            this.txtGroupName.Size = new System.Drawing.Size(144, 29);
            this.txtGroupName.TabIndex = 0;
            // 
            // btnaddgroup2
            // 
            this.btnaddgroup2.Location = new System.Drawing.Point(207, 52);
            this.btnaddgroup2.Name = "btnaddgroup2";
            this.btnaddgroup2.Size = new System.Drawing.Size(102, 29);
            this.btnaddgroup2.TabIndex = 2;
            this.btnaddgroup2.Text = "Add";
            this.btnaddgroup2.UseVisualStyleBackColor = true;
            this.btnaddgroup2.Click += new System.EventHandler(this.btnaddgroup2_Click);
            // 
            // GroupViaAdm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1061, 480);
            this.Controls.Add(this.addGroupPanel);
            this.Controls.Add(this.btngroupAdd);
            this.Controls.Add(this.dtgGroupList);
            this.Name = "GroupViaAdm";
            this.Text = "GroupViaAdm";
            this.Load += new System.EventHandler(this.GroupViaAdm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgGroupList)).EndInit();
            this.addGroupPanel.ResumeLayout(false);
            this.addGroupPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgGroupList;
        private System.Windows.Forms.Button btngroupAdd;
        private System.Windows.Forms.Panel addGroupPanel;
        private System.Windows.Forms.Label lblgroupname;
        private System.Windows.Forms.TextBox txtGroupName;
        private System.Windows.Forms.Button btnaddgroup2;
    }
}