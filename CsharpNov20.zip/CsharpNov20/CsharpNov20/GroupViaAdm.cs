﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CsharpNov20.Models;

namespace CsharpNov20
{
    public partial class GroupViaAdm : Form
    {
        MyAcademyEntities adb;
        public GroupViaAdm()
        {
            adb = new MyAcademyEntities();
            InitializeComponent();
        }

        private void GroupViaAdm_Load(object sender, EventArgs e)
        {
            dtgupdate();
        }

        private void dtgupdate()
        {

            dtgGroupList.DataSource = adb.Groups.Select(g => new
            {
                ID = g.ID,
                Groupname = g.Name,
                Status = g.Status
            }).ToList();
        }

        private void btngroupAdd_Click(object sender, EventArgs e)
        {
            addGroupPanel.Visible = true;
        }

        private void btnaddgroup2_Click(object sender, EventArgs e)
        {
            string groupname = txtGroupName.Text;
            if (string.IsNullOrEmpty(groupname) || (adb.Groups.FirstOrDefault(g => g.Name==groupname)!=null))
            {
                MessageBox.Show("Empty field and repeated group names are not accepted, please try agein");
                return;
            }
            Group newGroup = new Group()
            {
                Name = groupname,
                Status = true
            };

            adb.Groups.Add(newGroup);
            adb.SaveChanges();
            dtgupdate();

            txtGroupName.Text = "";
        }
    }
}
