﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace CsharpNov20
{
    class Hashit
    {
        public static string Hasher(string password)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(password);
            byte[] crypt = new SHA256Managed().ComputeHash(bytes);
            string hashedPassword = Encoding.Unicode.GetString(crypt);

            return hashedPassword;
        }

        public static bool Checker(string hashePassword, string password)
        {
            return Hasher(password) == hashePassword;
        }
    }
}
